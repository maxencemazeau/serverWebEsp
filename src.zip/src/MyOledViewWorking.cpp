// /**

// */
// #include <Arduino.h>
// #include "MyOledViewWorking.h"
// using namespace std;

// void MyOledViewWorking::init(std::string _id) {

//     Serial.println("Init dans MyOledViewWorking");
//     myId = _id;
//     params.clear();
//     }


//     void MyOledViewWifiAp::update(Adafruit_SSD1306 *adafruit){
//     Serial.println('Update Display Adafruit')
// }

// void MyOledViewWifiAp::display(Adafruit_SSD1306 *adafruit){

//        adafruit-> setTextSize(1);
//       adafruit->setTextColor(WHITE);
//       adafruit->setCursor(0,0);
//       adafruit->println("Hello, world!");
//       adafruit->display();

//       adafruit-> setTextSize(1);
//       adafruit->setTextColor(WHITE);
//       adafruit->setCursor(0,0);
//       adafruit->println("Hello, world!");
//       adafruit->display();

//       adafruit-> setTextSize(1);
//       adafruit->setTextColor(WHITE);
//       adafruit->setCursor(0,0);
//       adafruit->println("Hello, world!");
//       adafruit->display();
// }