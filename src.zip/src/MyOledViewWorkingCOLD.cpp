
// #include <MyOledViewWorkingCOLD.h>
// #include<Arduino.h>



// void MyOledViewWorkingCOLD::update(Adafruit_SSD1306 *adafruit){
//     Serial.println('Update Display Adafruit')
// }

// void MyOledViewWorkingCOLD::display(Adafruit_SSD1306 *adafruit){

//       adafruit-> setTextSize(1);
//       adafruit->setTextColor(WHITE);
//       adafruit->setCursor(0,0);
//       adafruit->println("Hello, world!");
//       adafruit->display();

//       adafruit-> setTextSize(1);
//       adafruit->setTextColor(WHITE);
//       adafruit->setCursor(0,0);
//       adafruit->println("Hello, world!");
//       adafruit->display();

//       adafruit-> setTextSize(1);
//       adafruit->setTextColor(WHITE);
//       adafruit->setCursor(0,0);
//       adafruit->println("Hello, world!");
//       adafruit->display();
// }