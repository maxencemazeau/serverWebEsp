


// #ifndef MYOLEDVIEW_H
// #define MYOLEDVIEW_H

// #include <Arduino.h>
// #include <Adafruit_SSD1306.h>


// class MyOledViewWorkingCOLD : public MyOledViewWorking {


//     private : 

//         virtual void display(Adafruit_SSD1306 * adafruit)= 0;
//         virtual void update(Adafruit_SSD1306 * adafruit)=0;
// }
